package com.example.tutorial02

data class NewsItem (var dept: String,var color: Int,var content: String )